import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:platform_converted_app/controller/provider/switch_provider.dart';
import 'package:platform_converted_app/models/switch_model.dart';
import 'package:platform_converted_app/views/screens/cupertino_app/home_page.dart';
import 'package:platform_converted_app/views/screens/material_app/home_page.dart';
import 'package:provider/provider.dart';
import 'package:shared_preferences/shared_preferences.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  SharedPreferences prefs = await SharedPreferences.getInstance();

  bool switchUi = prefs.getBool("switchUi") ?? false;

  runApp(
    MultiProvider(
      providers: [
        ChangeNotifierProvider(
          create: (context) => AppProvider(
            appModel: AppModel(switchValue: switchUi),
          ),
        )
      ],
      builder: (context, _) {
        return (Provider.of<AppProvider>(context).appModel.switchValue == false)
            ? MaterialApp(
                theme: ThemeData(
                  useMaterial3: true,
                ),
                debugShowCheckedModeBanner: false,
                routes: {
                  '/': (context) => homepage(),
                },
              )
            : CupertinoApp(
                debugShowCheckedModeBanner: false,
                routes: {
                  '/': (context) => HomePage(),
                },
              );
      },
    ),
  );
}
