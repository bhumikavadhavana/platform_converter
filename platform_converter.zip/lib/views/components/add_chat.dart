import 'package:flutter/material.dart';
import 'package:flutter/cupertino.dart';

class addchat extends StatefulWidget {
  const addchat({Key? key}) : super(key: key);

  @override
  State<addchat> createState() => _addchatState();
}

class _addchatState extends State<addchat> {
  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.all(12),
      child: Container(
        child: SingleChildScrollView(
          child: Column(
            children: [
              CircleAvatar(
                radius: 60,
                backgroundColor: Colors.deepPurpleAccent,
                child: Icon(Icons.add_a_photo_outlined,
                color: Colors.white,),
              ),
              SizedBox(
                height: 20,
              ),
              TextFormField(
                decoration: InputDecoration(
                  prefixIcon: Icon(Icons.person_outline_rounded),
                  labelText: "Full Name",
                  border: OutlineInputBorder(),
                ),
              ),
              SizedBox(
                height: 20,
              ),
              TextFormField(
                decoration: InputDecoration(
                  prefixIcon: Icon(Icons.call),
                  labelText: "Phone Number",
                  border: OutlineInputBorder(),
                ),
              ),
              SizedBox(
                height: 20,
              ),
              TextFormField(
                decoration: InputDecoration(
                  prefixIcon: Icon(Icons.message_outlined),
                  labelText: "Chat Conversation",
                  border: OutlineInputBorder(),
                ),
              ),
              SizedBox(
                height: 20,
              ),
              GestureDetector(
                child: Row(
                  children: [
                    Icon(Icons.calendar_month_rounded),
                    SizedBox(
                      width: 10,
                    ),
                    Text(
                      "Pick Date",
                    ),
                  ],
                ),
              ),
              SizedBox(
                height: 20,
              ),
              GestureDetector(
                child: Row(
                  children: [
                    Icon(Icons.access_time_filled_outlined),
                    SizedBox(
                      width: 10,
                    ),
                    Text(
                      "Pick Time",
                    ),
                  ],
                ),
              ),
              SizedBox(
                height: 20,
              ),
              OutlinedButton(
                onPressed: () {},
                child: Text("SAVE"),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
