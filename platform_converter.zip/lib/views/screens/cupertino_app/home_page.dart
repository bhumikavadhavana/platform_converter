import 'package:flutter/cupertino.dart';
import 'package:platform_converted_app/controller/provider/switch_provider.dart';
import 'package:provider/provider.dart';

class HomePage extends StatefulWidget {
  const HomePage({Key? key}) : super(key: key);

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  @override
  Widget build(BuildContext context) {
    return CupertinoPageScaffold(
      navigationBar: CupertinoNavigationBar(
          middle: Text(
            "Platform Converter",
            style: TextStyle(
              fontSize: 24,
              fontWeight: FontWeight.bold,
            ),
          ),
          trailing: CupertinoSwitch(
              value: Provider.of<AppProvider>(context).appModel.switchValue,
              onChanged: (val) {
                Provider.of<AppProvider>(context, listen: false).switchUi();
              })),
      child: Column(),
    );
  }
}
