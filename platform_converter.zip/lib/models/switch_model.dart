import 'package:provider/provider.dart';

class AppModel
{
  bool switchValue;

  AppModel({required this.switchValue});
}
