import 'package:flutter/material.dart';
import 'package:platform_converted_app/models/switch_model.dart';
import 'package:shared_preferences/shared_preferences.dart';

class AppProvider extends ChangeNotifier {
  AppModel appModel;

  AppProvider({required this.appModel});

  switchUi() async {
    appModel.switchValue = !appModel.switchValue;

    SharedPreferences prefs = await SharedPreferences.getInstance();
    prefs.setBool("switchUi", appModel.switchValue);
    notifyListeners();
  }
}
